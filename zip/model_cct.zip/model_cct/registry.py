

def register_model(func):
    """
    Fallback wrapper in case timm isn't installed
    """
    return func
